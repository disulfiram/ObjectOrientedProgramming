﻿using System;

namespace Student.Enum
{
    enum Specialities
    {
        Art,
        History,
        Science,
    }
}
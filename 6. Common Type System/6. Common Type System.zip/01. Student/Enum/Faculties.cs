﻿using System;

namespace Student.Enum
{
    enum Faculties
    {
        Biology,
        Chemistry,
        Economy,
    }
}
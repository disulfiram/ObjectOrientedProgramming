﻿using System;

namespace Student.Enum
{
    enum Univeristies
    {
        TU,
        SU,
        NBU,
        UNSS,
        UACG,
    }
}

﻿using System;

namespace Student.Enum
{
    enum Country
    {
        Bulgaria,
        England,
        Spain,
        Greace,
        France,
        Luxemburg,
    }
}

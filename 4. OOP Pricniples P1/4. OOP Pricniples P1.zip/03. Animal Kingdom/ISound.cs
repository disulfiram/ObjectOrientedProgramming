﻿using System;

namespace Animal_Kingdom
{
    interface ISound
    {
        void Sound();
    }
}
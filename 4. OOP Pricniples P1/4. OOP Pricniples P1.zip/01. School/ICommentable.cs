﻿using System;

namespace School        //I was wondering wether the comment field should be accessed by method or by propertie.
{
    public interface ICommentable
    {
        string Comment { get; set; }
    }
}
